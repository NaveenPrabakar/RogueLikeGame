#ifndef ROOM_H
#define ROOM_H

class Room {
public:
    int cx; 
    int cy; 
    int lx; 
    int ly;
    int d1; 
    int d2; 

    
    Room() : cx(0), cy(0), lx(0), ly(0), d1(0), d2(0) {}

};

#endif 