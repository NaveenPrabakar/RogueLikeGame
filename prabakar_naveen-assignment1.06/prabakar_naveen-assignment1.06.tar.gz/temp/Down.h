#ifndef DOWN_H
#define DOWN_H

class Down {
public:
    int dx;
    int dy;

    
    Down() : dx(0),dy(0) {}

};

#endif 