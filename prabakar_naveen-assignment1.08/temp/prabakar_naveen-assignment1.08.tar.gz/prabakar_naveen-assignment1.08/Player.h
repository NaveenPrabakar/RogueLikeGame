#ifndef PLAYER_H
#define PLAYER_H



class Player {
    public:
        int px;
        int py;
        char pr;
       
        Player() : px(0), py(0), pr('P') {}
    };

#endif