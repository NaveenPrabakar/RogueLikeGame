#ifndef UP_H
#define UP_H

class Up {
public:
    int ux;
    int uy;

    
    Up() : ux(0),uy(0) {}

};

#endif 