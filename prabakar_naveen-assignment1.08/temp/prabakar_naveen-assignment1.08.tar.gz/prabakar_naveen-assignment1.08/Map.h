#ifndef MAP_H
#define MAP_H


class Map {
    public:
        int tunnel;
        int non;
    
        
        Map() : tunnel(-1), non(-1){}
    };
    
#endif 